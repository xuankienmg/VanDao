/* Vấn Đạo · js/main.js: vòng lặp, tooltip, hiệu ứng đột phá, Admin, khởi động. Tách từ index.html (tools/split_index.py). */
/* ============================================================
   VÒNG LẶP & KHỞI ĐỘNG
   ============================================================ */
let lastFrame = performance.now(), lastLive = 0;
function frame(now){
  const dt = Math.min(.1, (now - lastFrame)/1000); lastFrame = now;
  if (W && S && MODE !== 'panel') drawScene(now/1000, dt);
  if (now - lastLive > 200){ live(); lastLive = now; }
  requestAnimationFrame(frame);
}

// Báo cho cửa sổ C# vùng nào là "có game": đĩa nhân vật + bảng thông tin.
// Ngoài vùng này cửa sổ trong suốt và chuột bấm xuyên qua xuống desktop.
let lastShape = '';
function reportShape(force){
  if (MODE !== 'strip' || !window.chrome?.webview) return;
  const d = devicePixelRatio || 1, c = cv.getBoundingClientRect();
  const qi = document.querySelector('.altar .qi').getBoundingClientRect(), al = document.querySelector('.altar').getBoundingClientRect();
  const px = v => Math.round(v * d);
  const shape = { card: {x:px(al.left), y:px(al.top), w:px(al.width), h:px(al.height), r:px(8)} };
  const json = JSON.stringify(shape);
  if (!force && json === lastShape) return;
  lastShape = json;
  notifyHost('shape', shape);
}
window.reportShape = reportShape;

// Tooltip khi rê chuột lên phần tử có data-tip (giữ trong vùng hiển thị của cửa sổ)
let tipEl = null;
function showTip(el){
  if (!el || !el.isConnected || !el.dataset.tip || (sortOpen && el.id === 'sortBtn') || (sellOpen && el.id === 'sellBtn')){ hideTip(); return; }
  tipEl = tipEl || $('tip');
  tipEl._for = el;
  if (el.dataset.card && el.dataset.k && ITEM[el.dataset.k]){ tipEl.innerHTML = itemCardHtml(el.dataset.k, el.dataset.card); tipEl.classList.add('card'); }
  else if (el.dataset.skcard && typeof skById === 'function' && skById(el.dataset.skcard)){ tipEl.innerHTML = skTipHtml(skById(el.dataset.skcard)); tipEl.classList.add('card'); }
  else {
    const [head, ...rest] = el.dataset.tip.split('\n');
    tipEl.innerHTML = `<b>${head}</b>${rest.length ? '\n' + rest.join('\n') : ''}`;
    tipEl.classList.remove('card');
  }
  tipEl.hidden = false;
  const r = el.getBoundingClientRect(), t = tipEl.getBoundingClientRect();
  let box = {left:4, top:4, right:innerWidth-4, bottom:innerHeight-4};
  if (MODE === 'strip'){ const q = document.querySelector('.altar').getBoundingClientRect(); box = {left:q.left+2, top:q.top+2, right:q.right-2, bottom:q.bottom-2}; }
  let x = r.left + r.width/2 - t.width/2, y = r.top - t.height - 6;
  if (tipEl.classList.contains('card')){
    // thẻ chi tiết: đặt bên phải ô, hết chỗ thì bên trái
    x = r.right + 8 + t.width <= box.right ? r.right + 8 : r.left - 8 - t.width;
    y = r.top;
  }
  else if (y < box.top) y = r.bottom + 6;
  if (y + t.height > box.bottom) y = Math.max(box.top, box.bottom - t.height);
  x = Math.max(box.left, Math.min(x, box.right - t.width));
  tipEl.style.left = x + 'px'; tipEl.style.top = y + 'px';
}
function hideTip(){ if (tipEl){ tipEl.hidden = true; tipEl._for = null; } }
document.addEventListener('mouseover', e => { const el = e.target.closest('[data-tip]'); if (el) showTip(el); else hideTip(); });
document.addEventListener('mouseleave', hideTip);
document.addEventListener('focusin', e => { const el = e.target.closest('[data-tip]'); if (el) showTip(el); });
document.addEventListener('focusout', hideTip);

// ===== Hiệu ứng đột phá =====
// kind: 'good' lên tầng · 'gold' lên cảnh giới mới · 'bad' thất bại
let breakFx = null, burstTimer = 0;
async function playBreak(kind, fromHost){
  if (kind === 'crit') kind = 'gold'; else if (kind === 'major') kind = 'bad';
  if (fromHost){                                 // cửa sổ khác vừa đột phá → lấy trạng thái mới trước
    await sync();
    await new Promise(r => requestAnimationFrame(() => requestAnimationFrame(r)));   // đợi lần vẽ lại xong rồi mới chạy hiệu ứng, tránh khựng khung đầu
  }
  const el = $('burst'), title = el.querySelector('b'), sub = el.querySelector('small');
  // chữ "Thành công" / "Thất bại" tách từng ký tự để chạy hiệu ứng lần lượt
  const word = kind === 'bad' ? 'Thất bại' : 'Thành công';
  title.innerHTML = [...word].map((ch, i) => `<i style="--i:${i}">${ch === ' ' ? '&nbsp;' : ch}</i>`).join('');
  if (kind === 'gold') sub.textContent = `Đột phá ${S.realmName} · thiên địa dị tượng`;
  else if (kind === 'bad') sub.textContent = `Linh khí phản phệ · lần sau +${Math.round(S.bonus*100)}% tỉ lệ`;
  else sub.textContent = `${S.realmName} ${S.stageName}`;
  el.className = 'burst ' + kind; el.hidden = true; void el.offsetWidth; el.hidden = false;   // chạy lại animation
  clearTimeout(burstTimer); burstTimer = setTimeout(() => { el.hidden = true; }, 2300);
  breakFx = {kind, t: 0, dur: kind === 'gold' ? 2.4 : kind === 'bad' ? 1.2 : 1.6};
  const r = realm();
  rings.push({t:0, c: kind === 'bad' ? '#e58472' : kind === 'gold' ? '#f2c94c' : r.aura, big: kind === 'gold'});
  if (kind === 'gold') setTimeout(() => rings.push({t:0, c: r.aura, big: true}), 350);
  if (typeof burst === 'function' && kind !== 'bad') burst(kind === 'gold' ? 60 : 24);
}
window.playBreak = playBreak;

// Các hàm cửa sổ desktop (C#) gọi vào
// =====================================================================
// ADMIN MODE: Ctrl+Shift+A bật/tắt (nhớ trong máy). Hiện tab Admin với lệnh gian lận để thử game.
// Cờ god / break / fast lưu ở server theo nhân vật (S.admin), các lệnh khác thực hiện một lần.
// =====================================================================
let adminOn = false;
try { adminOn = localStorage.getItem('van-dao-admin') === '1'; } catch(e){}
function setAdmin(on){
  adminOn = on; try { localStorage.setItem('van-dao-admin', on ? '1' : '0'); } catch(e){}
  document.body.classList.toggle('admin-on', on);
  const t = $('tab-admin'); if (t) t.hidden = !on;
  if (S && DATA) renderMap();                   // mô tả ô ải chỉ hiện khi bật admin
  if (on){ renderAdmin(true); openTab('admin'); } else if ($('tab-admin')?.getAttribute('aria-selected') === 'true') openTab('req');
  localLog(on ? 'Admin mode: BẬT (Ctrl+Shift+A để tắt)' : 'Admin mode: TẮT', on ? 'good' : '');
}
addEventListener('keydown', e => {
  if (e.ctrlKey && e.shiftKey && (e.key === 'A' || e.key === 'a')){ e.preventDefault(); setAdmin(!adminOn); }
  // phím ẩn Alt+Shift+R: reset nhân vật về từ đầu (bấm 2 lần trong 3 giây để xác nhận, giống nút trong Admin)
  if (e.altKey && e.shiftKey && !e.ctrlKey && e.code === 'KeyR'){
    e.preventDefault();
    if (Date.now() - resetArmAt < 3000){ resetArmAt = 0; adminAct('resetall'); }
    else { resetArmAt = Date.now(); localLog('Nhấn Alt+Shift+R lần nữa trong 3 giây để reset nhân vật về từ đầu (mất toàn bộ tiến trình).', 'bad'); }
  }
});
let resetArmAt = 0;
const adminAct = (action, arg, n) => act(`admin/${action}?${new URLSearchParams({...(arg != null ? {arg} : {}), ...(n ? {n} : {})})}`);
let admKey = '';
/** Admin: cờ "boss" — khiêu chiến Boss không cần chìa khóa. */
const adminBoss = () => (S?.admin || '').split(',').includes('boss');
function renderAdmin(force){
  const pane = $('pane-admin'); if (!pane || !S) return;
  document.body.classList.toggle('admin-on', adminOn);
  $('tab-admin').hidden = !adminOn;
  if (!adminOn){ pane.innerHTML = ''; admKey = ''; return; }
  const flags = (S.admin || '').split(',').filter(Boolean);
  // trạng thái game cập nhật liên tục: chỉ vẽ lại khi có thay đổi liên quan, để không mất ô đang nhập
  const key = [S.admin, S.skillPoints, S.realm, S.stage].join('|');
  if (!force && key === admKey && pane.innerHTML) return;
  admKey = key;
  const keepItem = $('admItem')?.value, keepN = $('admN')?.value, keepRealm = $('admRealm')?.value;
  const keepGear = $('admGear')?.value, keepQ = $('admQ')?.value, keepGN = $('admGN')?.value;
  // trang bị: chọn theo món gốc (nhóm theo bộ, kèm cấp + cảnh giới yêu cầu), phẩm chọn riêng
  const bases = DATA.items.filter(i => i.base && i.id.endsWith('q0'));
  const sets = [...new Set(bases.map(b => b.set || 'Khác'))];
  const gearOpts = sets.map(st => `<optgroup label="Bộ ${st} · cấp ${bases.find(b => (b.set || 'Khác') === st).itemLevel}">${bases.filter(b => (b.set || 'Khác') === st)
    .map(b => `<option value="${b.base}" data-set="${b.set || ''}" ${b.base === keepGear ? 'selected' : ''}>${b.name} · ${b.kind || ''} (cấp ${b.itemLevel} · ${DATA.realms[b.minRealm || 0].name})</option>`).join('')}</optgroup>`).join('');
  const items = DATA.items.filter(i => !i.base).sort((a, b) => RAR_KEYS.indexOf(a.rarity) - RAR_KEYS.indexOf(b.rarity));   // trang bị chọn ở mục Trang bị bên dưới
  const realms = DATA.realms.flatMap((r, i) => r.stages.map((st, j) => `<option value="${i}:${j}" ${i === S.realm && j === S.stage ? 'selected' : ''}>${r.name} · ${st}</option>`)).join('');
  const F = (id, n, d) => `<button data-adm="flag" data-arg="${id}" class="${flags.includes(id) ? 'on' : ''}" title="${d}">${n}: ${flags.includes(id) ? 'BẬT' : 'tắt'}</button>`;
  pane.innerHTML = `<div class="adm-p">
    <section><h4>Chế độ</h4><div class="adm-row">${F('god', 'Bất tử', 'Quái không gây sát thương, không thua trận')}${F('break', 'Đột phá chắc chắn', 'Tỉ lệ 100%, bỏ điều tức')}<span class="adm-grp">Thám hiểm nhanh: ${['fast2', 'fast3', 'fast5'].map(id => `<button data-adm="flag" data-arg="${id}" class="${flags.includes(id) || (id === 'fast3' && flags.includes('fast')) ? 'on' : ''}" title="Mỗi chuyến nhanh gấp ${id.slice(4)} lần · bấm lần nữa để tắt">×${id.slice(4)}</button>`).join('')}</span>${F('boss', 'Boss không cần chìa khóa', 'Khiêu chiến Boss không cần và không tiêu hao chìa khóa, đánh liên tục tới khi rời ải Boss')}</div>
      <small>Ctrl+Shift+A để ẩn / hiện admin mode. Cờ chế độ lưu theo nhân vật cho tới khi tắt.</small></section>
    <section><h4>Tài nguyên & vật phẩm</h4>
      <div class="adm-row"><button data-adm="stones" data-n="1000">+1.000 linh thạch</button><button data-adm="stones" data-n="100000">+100.000</button><button data-adm="stones" data-n="10000000">+10 triệu</button></div>
      <div class="adm-row"><select id="admItem">${items.map(it => `<option value="${it.id}" ${it.id === keepItem ? 'selected' : ''}>${it.name} · ${rar(it).n}${it.slot ? '' : ' · ' + (it.kind || '')}</option>`).join('')}</select>
        <input id="admN" type="number" min="1" value="${keepN || 1}"><button data-adm="give">Nhận</button></div></section>
    <section><h4>Trang bị</h4>
      <div class="adm-row"><select id="admGear">${gearOpts}</select>
        <select id="admQ">${Q_NAMES.map((q, i) => `<option value="${i}" ${String(i) === (keepQ ?? String(Q_NAMES.length - 1)) ? 'selected' : ''}>${q}</option>`).join('')}</select>
        <input id="admGN" type="number" min="1" value="${keepGN || 1}"><button data-adm="givegear">Nhận món</button><button data-adm="giveset">Nhận cả bộ</button></div>
      <small>Chọn món (theo bộ · cấp) và phẩm. "Nhận cả bộ" cho mọi món của bộ đang chọn ở phẩm đó.</small></section>
    <section><h4>Tu vi & cảnh giới</h4>
      <div class="adm-row"><button data-adm="qi">Đầy tu vi</button><button data-adm="clearcd">Xóa điều tức / suy yếu</button></div>
      <div class="adm-row"><select id="admRealm">${realms}</select><button data-adm="realm">Chuyển tới</button></div></section>
    <section><h4>Kỹ năng</h4>
      <div class="adm-row"><button data-adm="points" data-n="5">+5 điểm</button><button data-adm="points" data-n="50">+50 điểm</button><button data-adm="maxfire">Học max cây Hỏa</button><button data-adm="resetskills">Reset cây kỹ năng</button></div>
      <small>Điểm kỹ năng: ${S.skillPoints}</small></section>
    <section><h4>Thám hiểm & trận đánh</h4>
      <div class="adm-row"><button data-adm="explore">Kết thúc chuyến ngay</button><button data-adm="unlock">Mở toàn bộ ải + chìa khóa Boss</button></div></section>
    <section><h4>Nhân vật</h4>
      <div class="adm-row"><button data-adm="resetall">Reset nhân vật về từ đầu</button></div>
      <small>Xóa toàn bộ tu vi, cảnh giới, vật phẩm, trang bị, kỹ năng, ải và nhật ký. Giữ tên và cờ chế độ admin.</small></section>
  </div>`;
  if (keepRealm && $('admRealm')) $('admRealm').value = keepRealm;
}
document.addEventListener('click', e => {
  const b = e.target.closest('#pane-admin [data-adm]'); if (!b) return;
  const a = b.dataset.adm;
  if (a === 'give') adminAct('give', $('admItem').value, Math.max(1, +$('admN').value || 1));
  else if (a === 'givegear'){ const base = $('admGear').value, v = DATA.items.find(i => i.base === base && i.id.endsWith('q' + $('admQ').value)); if (v) adminAct('give', v.id, Math.max(1, +$('admGN').value || 1)); }
  else if (a === 'giveset'){ const o = $('admGear').selectedOptions[0]; if (o?.dataset.set) adminAct('giveset', `${o.dataset.set}|${$('admQ').value}`, Math.max(1, +$('admGN').value || 1)); }
  else if (a === 'realm') adminAct('realm', $('admRealm').value);
  else if (a === 'resetskills' && !b.dataset.armed){ b.dataset.armed = 1; b.textContent = 'Bấm lần nữa để reset'; setTimeout(() => renderAdmin(true), 3000); }
  else if (a === 'resetall' && !b.dataset.armed){ b.dataset.armed = 1; b.textContent = 'Bấm lần nữa để xóa sạch nhân vật'; setTimeout(() => renderAdmin(true), 3000); }
  else adminAct(a, b.dataset.arg ?? null, b.dataset.n ? +b.dataset.n : 0);
});
function openTab(name, exact){
  if (name === 'craft' && !exact) name = 'fuse';                // tab Luyện chế: mặc định mở Luyện khí
  if (LC_SUBS.includes(name)) lcSub = name;
  const top = name === 'fuse' || name === 'sell' || name === 'spin' ? 'craft' : name;
  document.querySelectorAll('.tab').forEach(x => x.setAttribute('aria-selected', x.dataset.tab === top));
  ['req','inv','craft','fuse','sell','spin','map','skill','admin'].forEach(id => $('pane-'+id).hidden = id !== name);
  document.querySelectorAll('[data-lc]').forEach(b => { b.classList.toggle('on', b.dataset.lc === name); b.setAttribute('aria-selected', b.dataset.lc === name); });
  if (MODE === 'panel' && typeof notifyHost === 'function') notifyHost('tab', {tab: name}); // cửa sổ đổi cỡ theo tab
}
window.openTab = openTab;
// sync() là hàm toàn cục nên C# gọi được window.sync() trực tiếp
window.setOpaque = on => document.body.classList.toggle('opaque', !!on);

async function boot(){
  try {
    DATA = await api('GET', '/api/data');
    DATA.items.forEach(i => ITEM[i.id] = i);
    let id = null; try { id = localStorage.getItem(KEY); } catch(e){}
    let st = null;
    if (id){ try { const r = await api('GET', `/api/players/${id}`); st = r.state ?? r; } catch(e){ if (e.status !== 404) throw e; } }
    // không có hoặc mất mã tu sĩ (cửa sổ desktop đổi cổng mỗi lần mở) → hỏi server tu sĩ đang chơi
    if (!st){ const r = await api('GET', '/api/players/current'); st = r.state ?? r; }
    try { localStorage.setItem(KEY, st.id); } catch(e){}
    setState(st);
  } catch(e){
    $('log').innerHTML = `<h3>Nhật ký tu hành</h3><p class="bad">${e.message} Hãy chạy server bằng lệnh dotnet run.</p>`;
    return;
  }
  resize(); addEventListener('resize', resize);
  $('btnBag').onclick = () => MODE === 'strip' ? notifyHost('open-panel', {tab:'inv'}) : openTab('inv');
  document.body.appendChild($('tip')); // tooltip phải nằm ngoài vùng bị ẩn ở chế độ bảng
  document.body.appendChild($('burst'));
  document.body.appendChild($('craftToast'));
  initInventory();
  // đột phá đại cảnh giới diễn ra trong tab Đột phá (trận pháp, 5 giai đoạn, kết quả); lên tầng thì làm ngay
  // nút Đột phá ngoài màn hình chính: luôn mở tab Đột phá (đột phá thật bấm trong tab, có trận pháp + kết quả)
  $('btnAdvance').onclick = () => MODE === 'strip' ? notifyHost('open-panel', {tab:'req'}) : openTab('req');
  initDan(); initMap(); initBreak(); initSkill();
  document.addEventListener('contextmenu', e => { if (MODE !== 'strip') e.preventDefault(); });
  document.querySelectorAll('.tab').forEach(t => t.onclick = () => openTab(t.dataset.tab));
  if (Q.get('tab')) openTab(Q.get('tab'));
  // dải taskbar: kéo thanh tiêu đề để di chuyển, mở bảng, mở menu cài đặt
  // kéo cả thanh tiêu đề (trừ nút cài đặt) để di chuyển cửa sổ
  document.querySelector('.strip-head').addEventListener('mousedown', e => {
    if (e.button !== 0 || e.target.closest('button')) return;
    e.preventDefault(); hideTip(); notifyHost('drag');
  });
  $('btnNext').onclick = () => {                                                      // sang ải kế, tối đa ải cao nhất đã mở
    const a = S.map.area, top = Math.min(S.map.areaMax, DATA.areas);
    if (a >= top || a > DATA.areas) return;
    mapPickAt = Date.now(); try { localStorage.setItem('van-dao-map-pick', mapPickAt); } catch(e){}
    act(`area/${a + 1}`);
  };
  $('btnPanel').onclick = () => MODE === 'strip' ? notifyHost('open-panel', {tab:'map'}) : openTab('map');
  $('btnMenu').onclick = () => notifyHost('menu');
  addEventListener('keydown', e => { if (e.key === 'Escape' && MODE === 'panel') notifyHost('close-panel'); });
  let armed = 0;
  $('btnReset').onclick = async () => {
    const b = $('btnReset');
    if (Date.now() - armed < 3000){ armed = 0; b.textContent='Tu lại từ đầu'; b.classList.remove('armed'); await act('reset'); return; }
    armed = Date.now(); b.textContent = 'Bấm lần nữa để xóa tiến độ'; b.classList.add('armed');
    setTimeout(() => { if (armed && Date.now()-armed >= 3000){ b.textContent='Tu lại từ đầu'; b.classList.remove('armed'); } }, 3100);
  };
  setInterval(sync, 4000);
  if (MODE === 'strip'){
    addEventListener('resize', () => reportShape()); setInterval(reportShape, 1000);
    // cửa sổ C# chỉ hiện dải khi nhận hình lần đầu → đợi font (tối đa 1.5s) và khung canvas đầu tiên đã vẽ xong
    const fontsReady = Promise.race([document.fonts?.ready, new Promise(r => setTimeout(r, 1500))]);
    fontsReady.then(() => requestAnimationFrame(() => requestAnimationFrame(() => reportShape(true))));
  }
  document.addEventListener('visibilitychange', () => { if (!document.hidden) sync(); });
  for (let i=0;i<30;i++) spawn(false);
  requestAnimationFrame(frame);
}
boot();
