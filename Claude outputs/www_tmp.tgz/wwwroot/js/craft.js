/* Vấn Đạo · js/craft.js: Đan dược: hợp thành, lò đan. Tách từ index.html (tools/split_index.py). */
// =====================================================================
// ĐAN DƯỢC: hợp thành 9 viên bậc dưới → 1 viên bậc trên. Đan chỉ dùng để lên tầng và đột phá.
// =====================================================================
let ddSel = null, ddErr = null, ddAnim = null;
try { ddSel = localStorage.getItem('van-dao-dd-sel'); } catch(e){}
const synthOf = k => DATA.synths.find(s => s.from === k);
const synthMax = k => S.map.synths.find(s => s.from === k)?.max || 0;
const stones = () => S.inventory.linh_thach || 0;

function ddCur(){
  const chain = DATA.pillChain;
  if (ddSel && chain.includes(ddSel)) return ddSel;
  return chain.find(k => synthOf(k) && (S.inventory[k] || 0) >= 9) || chain[0];
}


function ddPillCard(k){
  const it = ITEM[k], n = S.inventory[k] || 0, sd = synthOf(k), sel = k === ddCur();
  let st, cls;
  if (!sd){ st = 'Bậc cao nhất'; cls = 'top'; }
  else if (n >= sd.count){ st = 'Hợp thành được'; cls = 'ok'; }
  else { st = `Thiếu ${sd.count - n}`; cls = 'miss'; }
  return `<button class="dd-card ${sel ? 'sel' : ''} ${cls}" data-pill="${k}" aria-pressed="${sel}" data-tip="${itemTip(k, st)}">
    <small class="dd-tier">Bậc ${it.tier}</small><span class="dd-fr r-${it.rarity}">${itemImg(k)}</span>
    <span class="dd-cn">${it.name}</span><b class="dd-cq">×${fmt(n)}</b>
    ${sd ? `<span class="dd-cp">${Math.min(n, sd.count)} / ${sd.count}</span>` : '<span class="dd-cp">—</span>'}
    <span class="dd-cs">${st}</span></button>`;
}

// ---- đan phương: luyện đan đặc biệt từ linh dược (Tẩy Tủy Đan, Phá Chướng Đan theo cảnh giới) ----
const brewRealm = id => id.startsWith('pha_chuong_dan_') ? +id.slice(15) : -1;
const brewMax = b => Math.min(...Object.entries(b.in).map(([k, c]) => Math.floor((S.inventory[k] || 0) / c)));
function ddBrewRow(b){
  const it = ITEM[b.out], max = brewMax(b), own = S.inventory[b.out] || 0, br = brewRealm(b.out);
  const ins = Object.entries(b.in).map(([k, c]) => { const h = S.inventory[k] || 0;
    return `<span class="br-in ${h >= c ? 'ok' : 'miss'}" data-tip="${itemTip(k)}">${itemImg(k)}<b>${k === 'linh_thach' ? fmt(c) : `${fmt(Math.min(h, c))}/${fmt(c)}`}</b></span>`; }).join('<i>+</i>');
  const note = br >= 0 && br !== S.realm ? `<small class="br-far">dùng ở ${DATA.realms[br].name}</small>` : '';
  return `<div class="dd-brew ${max ? 'ok' : ''}">
    <span class="dd-fr r-${it.rarity}" data-tip="${itemTip(b.out)}">${itemImg(b.out)}</span>
    <div class="br-mid"><p class="nm"><b class="rc-${it.rarity}">${it.name}</b> <small>đang có ${fmt(own)}</small>${note}</p><div class="br-ins">${ins}</div></div>
    <div class="br-act"><button class="dd-all" data-brew="${b.out}" data-n="1" ${max ? '' : 'disabled'}>Luyện</button>
      <button class="dd-all" data-brew="${b.out}" data-n="0" ${max > 1 ? '' : 'disabled'} data-tip="Luyện tối đa: ${max} lần">×${max}</button></div></div>`;
}
function ddBrews(){
  // Tẩy Tủy Đan + Phá Chướng Đan của cảnh giới hiện tại và kế tiếp
  const list = (DATA.brews || []).filter(b => { const r = brewRealm(b.out); return r < 0 || r === S.realm || r === S.realm + 1; });
  if (!list.length) return '';
  const pb = S.pillBonus ? ` · Phá Chướng đang có hiệu lực <b>+${Math.round(S.pillBonus * 100)}%</b>` : '';
  return `<p class="dd-sec">Đan phương · luyện từ linh dược rơi khi diệt yêu${pb}</p><div class="dd-brews">${list.map(ddBrewRow).join('')}</div>`;
}

function ddBreak(){
  const r = realm();
  if (S.isPeak && !S.hasNext)
    return `<p class="dd-sec">Đột phá kế tiếp</p><p class="dd-now">${S.realmName} ${S.stageName}</p><p class="dd-note">Cảnh giới ${DATA.lockedRealms[0]} chưa khai mở. Tích lũy đan dược và yêu hạch chờ bản cập nhật sau.</p>`;
  const q = qiNow(), full = q >= S.qiReq;
  const cur = `${S.realmName} ${S.stageName}`, next = S.isPeak ? DATA.realms[S.realm + 1].name : S.targetTitle.replace(' · ', ' ');
  const row = (ok, ic, name, val, extra = '') => `<li class="${ok ? 'ok' : 'no'} ${extra}"><i>${ok ? '✓' : '✗'}</i>${ic}<span>${name}</span><b>${val}</b></li>`;
  let rows = row(full, '', 'Tu vi', `<span id="ddQi2">${fmt(q)} / ${fmt(S.qiReq)}</span>`);
  let bossBox = '';
  for (const c of S.targetCost){
    const it = ITEM[c.item], ok = c.have >= c.need;
    if (it.type === 'boss'){
      bossBox = `<div class="dd-boss ${ok ? 'ok' : ''}" data-tip="${itemTip(c.item)}">
        <span class="dd-fr boss">${itemImg(c.item)}</span>
        <div><p class="nm">${it.name}</p><p class="st">${fmt(c.have)} / ${c.need} · nguyên liệu Boss</p>
        <p class="hint">${ok ? 'Đã có, sẵn sàng đột phá.' : `Đánh bại Boss ${r.boss}${bossChapterTag(r.bossItem)} để nhận nguyên liệu.`}</p></div></div>`;
      rows += row(ok, '', it.name, `${fmt(c.have)} / ${c.need}`, 'bossrow');
    } else rows += row(ok, itemImg(c.item), it.name, `${fmt(c.have)} / ${fmt(c.need)}`);
  }
  const ready = full && hasAll(S.targetCost);
  const needBoss = S.isPeak && S.targetCost.some(c => ITEM[c.item].type === 'boss' && c.have < c.need);
  const btn = ready ? `<button class="dd-go gold" data-dd="advance">Đột phá</button>`
    : needBoss ? `<button class="dd-go" data-dd="boss">Đến khu vực Boss</button>` : '';
  const upcoming = !S.isPeak && ITEM[r.bossItem] ? `<p class="dd-note">Đại cảnh giới ${DATA.realms[S.realm + 1] ? DATA.realms[S.realm + 1].name : DATA.lockedRealms[0]} cần thêm ${itemImg(r.bossItem)} <b>${ITEM[r.bossItem].name}</b> (Boss ${r.boss}${bossChapterTag(r.bossItem)}).</p>` : '';
  return `<p class="dd-sec">${S.isPeak ? 'Đột phá kế tiếp' : 'Đột phá tầng kế tiếp'}</p>
    <div class="dd-path"><span>${cur}</span><i>→</i><b>${next}</b></div>
    <ul class="dd-req">${rows}</ul>${bossBox}${btn}${upcoming}`;
}

function renderCraft(){
  const pane = $('pane-craft');
  if (!$('ddCanvas')){
    pane.innerHTML = `<div class="dd">
      <header class="dd-top">${lcNav('craft')}<div class="dd-cult" id="ddCult"></div><div class="dd-stone" id="ddStone"></div></header>
      <section class="dd-main">
        <div class="dd-synth" id="ddSynth">
          <div class="dd-io" id="ddIn"></div>
          <div class="dd-fur"><canvas id="ddCanvas" width="160" height="144" aria-label="Lò đan"></canvas></div>
          <div class="dd-io" id="ddOut"></div>
          <div class="dd-act" id="ddAct"></div>
        </div>
        <div class="dd-inv" id="ddInv"></div>
      </section>
      <aside class="dd-side"><div class="dd-use" id="ddUse"></div><div class="dd-break" id="ddBreak"></div></aside>
    </div>`;
  }
  const k = ddCur(), it = ITEM[k], sd = synthOf(k), n = S.inventory[k] || 0, max = synthMax(k);
  $('ddStone').innerHTML = `${itemImg('linh_thach')}<span>Linh thạch</span><b>× ${fmt(stones())}</b>${hpStoneHtml('dd-hp')}`;
  $('ddIn').innerHTML = `<span class="dd-lab">Đan bậc ${it.tier}</span><span class="dd-fr big r-${it.rarity}">${itemImg(k)}</span>
    <span class="dd-nm">${it.name}</span><b class="dd-cnt ${sd && n >= sd.count ? 'ok' : 'miss'}">${sd ? `${Math.min(n, sd.count)} / ${sd.count}` : `× ${fmt(n)}`}</b>`;
  if (sd){
    const to = ITEM[sd.to];
    $('ddOut').innerHTML = `<span class="dd-lab">Đan bậc ${to.tier}</span><span class="dd-fr big r-${to.rarity}">${itemImg(sd.to)}</span>
      <span class="dd-nm">${to.name}</span><b class="dd-cnt out">1</b><small class="dd-have">Đang có ${fmt(S.inventory[sd.to] || 0)}</small>`;
    const herbs = Object.entries(sd.herbs || {}), hMiss = herbs.find(([h, c]) => (S.inventory[h] || 0) < c);
    const why = n < sd.count ? `Thiếu ${sd.count - n} ${it.name}` : hMiss ? `Thiếu ${hMiss[1] - (S.inventory[hMiss[0]] || 0)} ${ITEM[hMiss[0]].name}` : stones() < sd.stones ? `Thiếu linh thạch (cần ${fmt(sd.stones)})` : '';
    const herbRow = herbs.map(([h, c]) => { const have = S.inventory[h] || 0;
      return `<span class="dd-herb ${have >= c ? 'ok' : 'miss'}" data-tip="${itemTip(h)}">${itemImg(h)}<b>${ITEM[h].name}</b> ${fmt(Math.min(have, c))} / ${c}</span>`; }).join('');
    $('ddAct').innerHTML = `<button class="dd-synth-btn" data-dd="synth" ${max > 0 ? '' : 'disabled'}>Hợp thành</button>
      <button class="dd-all" data-dd="all" ${max > 1 ? '' : 'disabled'} data-tip="Hợp thành tất cả: ${max} lần">Tối đa ×${max}</button>
      ${herbRow ? `<p class="dd-herbs">Linh thảo ${herbRow}</p>` : ''}
      <p class="dd-fee">${why ? `<span class="miss">${why}</span> · ` : ''}Phí ${itemImg('linh_thach')} ${fmt(sd.stones)} · luôn thành công</p>`;
  } else {
    $('ddOut').innerHTML = `<span class="dd-lab">Bậc cao nhất</span><span class="dd-fr big empty"></span><span class="dd-nm">Không hợp thành tiếp</span>`;
    $('ddAct').innerHTML = `<p class="dd-fee">${it.name} là đan bậc cao nhất hiện có.</p>`;
  }
  // đan trong hành trang xếp theo chuỗi hợp thành: bậc 1 →(9:1)→ bậc 2 →(9:1)→ bậc 3 → bậc 4
  $('ddInv').innerHTML = `<p class="dd-sec">Đan dược trong hành trang · chuỗi hợp thành</p><div class="dd-cards">${DATA.pillChain.map(ddPillCard).join('<i class="dd-arr">→<small>9 : 1</small></i>')}</div>${ddBrews()}`;
  $('ddUse').innerHTML = `<p class="dd-sec">Công dụng</p><div class="dd-use-hd">${itemImg(k)}<b class="rc-${it.rarity}">${it.name}</b></div>
    <p class="dd-use-tx">${it.use || it.desc}</p><p class="dd-note">Đan dược chỉ dùng để đột phá tầng và cảnh giới, không hồi máu, không hồi linh khí.</p>`;
  $('ddBreak').innerHTML = ddBreak();
  liveDan();
}

function liveDan(){
  if (!S || !$('ddCult')) return;
  const q = qiNow(), rq = S.qiReq;
  $('ddCult').innerHTML = `<span>Cảnh giới <b>${S.realmName}</b> · <b>${S.stageName}</b></span>
    <div class="dd-qi"><i style="width:${Math.min(100, q / rq * 100)}%"></i><em>${fmt(q)} / ${fmt(rq)} tu vi</em></div>`;
  const q2 = $('ddQi2'); if (q2) q2.textContent = `${fmt(q)} / ${fmt(rq)}`;
}

// ---- lò đan pixel: nghỉ · đang hợp thành · thành đan ----
const ddImg = {};
// ảnh lò nét gấp đôi canvas logic (img/furnace2_*.png, cắt lại: tools/cut_furnace.py)
['furnace_body','furnace_lid','furnace_runes'].forEach(k => { const im = new Image(); im.src = `img/${k.replace('furnace_', 'furnace2_')}.png`; ddImg[k] = im; });
const ddDraw = (g, k, x, y) => { const im = ddImg[k]; if (im.complete && im.naturalWidth) g.drawImage(im, x, y, im.naturalWidth / 2, im.naturalHeight / 2); };
const ddFx = {smoke: [], sparks: [], t: 0, last: 0};
const FIRE_O = ['#fff1b8','#ffd27a','#ff9a3c','#e0562a','#8a2a1a'];
const FIRE_C = ['#eaffff','#9ff6ee','#4fd6d0','#2a8f9a','#1d4d5a'];
function ddSizeCanvas(c){
  const box = c.parentElement.getBoundingClientRect();
  if (!box.width) return false;
  const sc = Math.max(2, Math.min(MODE === 'panel' ? 2 : 3, Math.floor(Math.min(box.width / 80, Math.max(144, box.height) / 72))));   // cửa sổ Tu luyện: giữ lò ×2 cho gọn
  c.style.width = 80 * sc + 'px'; c.style.height = 72 * sc + 'px';
  return true;
}
function ddFrame(now){
  requestAnimationFrame(ddFrame);
  const c = $('ddCanvas');
  if (!c || !S || !c.offsetParent) return;
  if (!c._sized) c._sized = ddSizeCanvas(c);
  const dt = Math.min(.1, (now - (ddFx.last || now)) / 1000); ddFx.last = now; ddFx.t += dt;
  const g = c.getContext('2d'); g.imageSmoothingEnabled = false; g.setTransform(2, 0, 0, 2, 0, 0);   // canvas 160×144, vẽ theo toạ độ logic 80×72
  const t = ddFx.t, ag = ddAnim ? (performance.now() - ddAnim.t0) / 1000 : 99;
  const fire = ag < .8, done = ag >= .8 && ag < 3.2, k = done ? (ag - .8) / 2.4 : 0;
  const heat = fire ? 1 : done ? .9 - k * .6 : .3;
  g.clearRect(0, 0, 80, 72);
  const P = (x, y, col, a = 1) => { g.globalAlpha = a; g.fillStyle = col; g.fillRect(Math.round(x), Math.round(y), 1, 1); };
  const glow = fire ? '#12403e' : done ? '#3e3412' : '#16201e';
  for (let r = 30; r > 0; r -= 6){ g.globalAlpha = .18; g.fillStyle = glow; g.beginPath(); g.ellipse(40, 44, r * 1.25, r, 0, 0, 7); g.fill(); }
  g.globalAlpha = 1;
  [['#3a322a', 25, 64, 30, 1], ['#2a2420', 21, 65, 38, 2], ['#1e1a16', 18, 67, 44, 2], ['#14110e', 20, 69, 40, 2]].forEach(([col, x, y, w, h]) => { g.fillStyle = col; g.fillRect(x, y, w, h); });
  for (let x = 25; x <= 55; x++){
    const cyan = x % 6 < 2;
    const n = Math.sin(x * 1.7 + t * 9) + Math.sin(x * .6 - t * 5.3) * .8 + Math.sin(t * 13 + x);
    const h = Math.max(0, Math.round((fire ? 6 : 2.2) * heat + n * (fire ? 2.2 : 1) * heat + (x > 34 && x < 46 ? 2 * heat : 0)));
    const pal = cyan ? FIRE_C : FIRE_O;
    for (let i = 0; i < h; i++) P(x, 64 - i, pal[Math.min(4, Math.floor(i / Math.max(1, h) * 4.2))], heat < .35 ? .65 : 1);
  }
  if (fire && Math.random() < dt * 18) ddFx.sparks.push({x: 28 + Math.random() * 26, y: 60, vx: (Math.random() - .5) * 6, vy: -10 - Math.random() * 8, life: 1, c: Math.random() < .5 ? '#9ff6ee' : '#ffd27a'});
  const fx = 9, fy = 10;
  ddDraw(g, 'furnace_body', fx, fy);
  const rune = fire ? .6 + .4 * Math.abs(Math.sin(t * 6)) : done ? 1 - k * .7 : .14 + .08 * Math.sin(t * 1.3);
  g.globalAlpha = rune; ddDraw(g, 'furnace_runes', fx, fy);
  g.globalAlpha = rune * .35; ddDraw(g, 'furnace_runes', fx - .5, fy); ddDraw(g, 'furnace_runes', fx + .5, fy); ddDraw(g, 'furnace_runes', fx, fy - .5);
  g.globalAlpha = 1;
  let lidY = fy;
  if (fire) lidY -= (t % .3 < .08) ? 1 : 0;
  if (done) lidY -= Math.round(12 * Math.min(1, (ag - .8) / .35));
  ddDraw(g, 'furnace_lid', fx, lidY);
  if (done && ddAnim){
    const it = ITEM[ddAnim.item], col = it?.color || '#e6c46a', tier = it?.tier || 1;
    const py = Math.round(27 - Math.min(7, (ag - .8) * 9) + Math.sin(t * 3) * 1.2);
    const rays = 2 + tier * 2;
    for (let i = 0; i < rays; i++){
      const a = t * .8 + i / rays * Math.PI * 2, L = 6 + tier * 2 + Math.sin(t * 4 + i) * 1.5;
      for (let d = 4; d < L; d++) P(40 + Math.cos(a) * d, py + Math.sin(a) * d, col, .6 * (1 - d / L));
    }
    g.globalAlpha = .35; g.fillStyle = col; g.fillRect(36, py - 4, 9, 9);
    g.globalAlpha = 1; g.fillStyle = '#1a120c'; g.fillRect(38, py - 2, 5, 5);
    g.fillStyle = col; g.fillRect(38, py - 1, 5, 3); g.fillRect(39, py - 2, 3, 5);
    g.fillStyle = '#fff'; g.fillRect(39, py - 1, 1, 1);
  }
  const rate = fire ? 14 : done ? 4 : 1.5;
  if (Math.random() < dt * rate) ddFx.smoke.push({x: 36 + Math.random() * 8, y: lidY + 2, vx: (Math.random() - .5) * 3, vy: -(4 + Math.random() * 5), life: 1, c: fire && Math.random() < .5 ? '#7ff0e6' : '#9aa6a2'});
  for (const s of ddFx.smoke){ s.x += (s.vx + Math.sin(t * 2 + s.y * .3) * 1.5) * dt; s.y += s.vy * dt; s.life -= dt * .4; P(s.x, s.y, s.c, Math.max(0, s.life) * (s.c === '#7ff0e6' ? .7 : .45)); }
  ddFx.smoke = ddFx.smoke.filter(s => s.life > 0 && s.y > -2);
  for (const s of ddFx.sparks){ s.x += s.vx * dt; s.y += s.vy * dt; s.vy += 6 * dt; s.life -= dt * 1.1; P(s.x, s.y, s.c, Math.max(0, s.life)); }
  ddFx.sparks = ddFx.sparks.filter(s => s.life > 0);
  if (fire) for (let i = 0; i < 8; i++){ const a = t * 2.4 + i / 8 * Math.PI * 2; P(40 + Math.cos(a) * 34, 40 + Math.sin(a) * 9, i % 2 ? '#7ff0e6' : '#e6fffb', .5 + .3 * Math.sin(a)); }
  g.globalAlpha = 1;
}
requestAnimationFrame(ddFrame);
addEventListener('resize', () => { const c = $('ddCanvas'); if (c) c._sized = false; });

// Thông báo luyện chế thành công: dùng chung cho mọi công thức (server trả thành phẩm + nguyên liệu đã tiêu hao)
let craftTimer = 0;
